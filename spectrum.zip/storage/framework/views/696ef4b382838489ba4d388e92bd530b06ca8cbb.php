<?php $__env->startSection('content'); ?>
<main class="content-wrapper">
    <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
        <div class="mdc-card p-0">
            <h6 class="card-title card-padding pb-0">Restore Deleted Books </h6>
            <?php if(isset($books)): ?>
            <?php if(empty($books)): ?>
            <p class="text-center">No Deleted Books Yet.</p>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hoverable">
                    <thead>
                        <tr>
                            <th>SN</th>
                            <th class="text-left">Book Name</th>
                            <th>Book Author</th>
                            <th>Book Publisher</th>
                            <th>Date Published</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php ($count = 0); ?>
                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php (++$count); ?>
                        <tr>
                            <td><?php echo e($count); ?></td>
                            <td class="text-left"><?php echo e($book->title); ?></td>
                            <td><?php echo e($book->author); ?></td>
                            <td><?php echo e($book->publisher); ?></td>
                            <td><?php echo e(date('Y-m-d', strtotime($book->date_published))); ?></td>
                            <td>
                                <a href="<?php echo e(url('admin/books/restore-book/'.$book->id)); ?>"
                                    class="mdc-button mdc-button--raised icon-button filled-button--primary">
                                    <i class="material-icons mdc-button__icon">visibility</i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
            <?php else: ?>
            <p class="text-center">No Deleted Books Yet.</p>
            <?php endif; ?>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\spectrum\resources\views/books/deleted-books.blade.php ENDPATH**/ ?>