<?php $__env->startSection('content'); ?>
  <used-licenses category="all"></used-licenses>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\spectrum\resources\views/licenses/used-licenses.blade.php ENDPATH**/ ?>