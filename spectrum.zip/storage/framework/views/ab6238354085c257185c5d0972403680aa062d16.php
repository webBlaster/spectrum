<?php $__env->startSection('content'); ?>
<main class="content-wrapper">
  <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
    <div class="mdc-card p-0 ml-2">
      <load-keys></load-keys>
  </div>
</main>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\spectrum\resources\views/admin/show-access-keys.blade.php ENDPATH**/ ?>