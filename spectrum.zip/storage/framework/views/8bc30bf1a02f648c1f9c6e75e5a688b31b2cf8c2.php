<?php $__env->startSection('content'); ?>
<div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
    <div class="mdc-card p-0">
        <h6 class="card-title card-padding pb-0">Audit Logs</h6>
        <?php if(isset($logs)): ?>
        <?php if(empty($logs)): ?>
        <p>No activity log recorded yet. </p>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hoverable">
                <thead>
                    <tr>
                        <th>SN</th>
                        <th class="text-left">Title</th>
                        <th>Action</th>
                        <th>Admin</th>
                        <th>Subject</th>
                        <th>Ip Address</th>
                        <th>Date and Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php ($count = 0); ?>
                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$count); ?></td>
                        <td class="text-left"><?php echo e($log->title); ?></td>
                        <td><?php echo e($log->action); ?></td>
                        <td><?php echo e($log->admin); ?></td>
                        <td><?php echo e($log->subject); ?></td>
                        <td><?php echo e($log->ip_address); ?></td>
                        <td><?php echo e(date('l jS F Y g:i:a', strtotime($log->created_at))); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <button type="button" class="export_btn" title="<?php echo e("Audit Logs ".date('l jS F Y \a\t g:i:a')); ?>">Export to CSV</button>
        </div>
        <?php endif; ?>
        <?php else: ?>
        <p>No activity log recorded yet. </p>
        <?php endif; ?>

    </div>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\spectrum\resources\views/admin/audit-logs.blade.php ENDPATH**/ ?>