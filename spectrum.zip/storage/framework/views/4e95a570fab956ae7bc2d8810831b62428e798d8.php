<?php $__env->startSection('content'); ?>

<main class="content-wrapper">
  <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
      <div class="mdc-card">
          <div class="d-flex justify-content-between align-items-center">
              <div class="mdc-card">
                  <div class="template-demo">
                    <?php if($trash): ?>
                        <thrashed-licenses></thrashed-licenses>
                    <?php else: ?>
                        <all-licenses></all-licenses>
                    <?php endif; ?>
                  </div>
              </div>
          </div>
      </div>
  </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\spectrum\resources\views/licenses/generated-licenses.blade.php ENDPATH**/ ?>