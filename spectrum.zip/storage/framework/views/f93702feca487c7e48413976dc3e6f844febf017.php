<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Spectrum Books</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/material.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/dataTables.material.min.css')); ?>">
    <!-- plugins:css -->

    <link rel="stylesheet" href="<?php echo e(asset('vendors/mdi/css/materialdesignicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/css/vendor.bundle.base.css')); ?>">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <link rel="stylesheet" href="<?php echo e(asset('vendors/flag-icon-css/css/flag-icon.min.css')); ?>">
    <!-- End plugin css for this page -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/demo/style.css')); ?>">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="<?php echo e(asset('images/Spectrum logo.png')); ?>" />


    <!-- plugins:js -->
    <script src="<?php echo e(asset('vendors/js/vendor.bundle.base.js')); ?>"></script>

    <style>
        table {
            width: 100%;
        }

    </style>
</head>

<body>
    <script src="<?php echo e(asset('js/preloader.js')); ?>"></script>
    <div class="body-wrapper" id="app">
        <?php if(Session::has('success')): ?>
        <flash-success message="<?php echo e(Session::get('success')); ?> "></flash-success>
        <?php endif; ?>
        <!-- partial -->



        <!-- dashboard -->

        <div class="page-wrapper mdc-toolbar-fixed-adjust">
            <!-- Sidebar -->
            <vue-progress-bar></vue-progress-bar>
            <?php echo $__env->make('layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="main-wrapper mdc-drawer-app-content">
                <!-- Header -->
                <?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- Page Content -->
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>

    <script src="<?php echo e(mix('js/app.js')); ?>"></script>

    <script src="<?php echo e(asset('js/material.js')); ?>"></script>
    <script src="<?php echo e(asset('js/misc.js')); ?>"></script>
    <!-- endinject -->
    <!-- Custom js for this page-->
    <script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
   <!-- End custom js for this page-->
 <script src="<?php echo e(asset('js/dataTables.min.js')); ?>"></script>
 <script src="<?php echo e(asset('js/dataTables.material.min.js')); ?>"></script>

<script>
    function exportTableToExcel(tableID, filename = '') {
        var downloadLink;
        var dataType = 'application/vnd.ms-excel';
        var tableSelect = document.getElementById(tableID);
        var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');

        // Specify file name
        filename = filename ? filename + '.xls' : 'excel_data.xls';

        // Create download link element
        downloadLink = document.createElement("a");

        document.body.appendChild(downloadLink);

        if (navigator.msSaveOrOpenBlob) {
            var blob = new Blob(['\ufeff', tableHTML], {
                type: dataType
            });
            navigator.msSaveOrOpenBlob(blob, filename);
        } else {
            // Create a link to the file
            downloadLink.href = 'data:' + dataType + ', ' + tableHTML;

            // Setting the file name
            downloadLink.download = filename;

            //triggering the function
            downloadLink.click();

            location.reload();
        }
    }

    $(document).ready(function() {
        $("button input").click(function() {
            if ($(this).attr('type') == "submit") {
                $(this).attr('disabled', 'disabled');
                $('form').not('#logout-form').submit();
            }
        });


        // $('table').DataTable({
        //     columnDefs: [{
        //         targets: [0, 1, 2]
        //         , className: 'mdl-data-table__cell--non-numeric'
        //     }]
        // });

        const urlsEqual = (urlProp1, urlProp2) => {
          const urls = new URL(urlProp1);
          if(urlProp2.includes(urls.pathname)) {
            return true;
          }
          return false;
        }
        const urls = [
          '/admin/licenses/used-licenses',
          '/admin/licenses/edit-license',
          '/admin/dashboard'
        ];
         
        if(!urlsEqual(window.location, urls)) {
          $('table').DataTable({
              columnDefs: [{
                  targets: [0, 1, 2]
                  , className: 'mdl-data-table__cell--non-numeric'
              }]
          });
        }

        


        $('.export_btn').click(function() {

            var filename = $(this).attr('title');
            var table_id = $('table').attr('id');

            exportTableToExcel(table_id, filename);
        });
    });
</script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\spectrum\resources\views/layouts/layout.blade.php ENDPATH**/ ?>