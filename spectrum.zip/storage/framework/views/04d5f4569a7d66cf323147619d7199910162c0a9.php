<?php $__env->startSection('content'); ?>

<div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
    <div class="mdc-card p-0">
        <h6 class="card-title card-padding pb-0">License Accounting Details</h6>
        <div class="table-responsive">
            <table class="table table-hoverable" style="width:100%;">
                <thead>
                    <tr>
                        <th>SN</th>
                        <th class="text-left">License Code</th>
                        <th>Price</th>
                        <th>Number of Users</th>
                        <th>Revenue</th>
                    </tr>
                </thead>
                <tbody>
                    <?php ($count = 0); ?>
                    <?php ($sum = $access_codes->sum('price')); ?>
                    <?php $__currentLoopData = $access_codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $access_code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php (++$count); ?>
                    <tr>
                        <td><?php echo e($count); ?></td>
                        <td class="text-left"><?php echo e($access_code->code); ?></td>
                        <td><?php echo e($access_code->price); ?></td>
                        <td><?php echo e($access_code->count); ?></td>
                        <td><?php echo e($access_code->count * $access_code->price); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td class="text-left" colspan="2">Summary and Totals</td>
                        <td><?php echo e($sum); ?></td>
                        <td class="text-right"><?php echo e($total_number_of_users); ?></td>
                        <td class="text-right"><?php echo e($total_revenue); ?></td>
                    </tr>
                </tfoot>
            </table>
            <button type="button" class="export_btn" title="<?php echo e("License Accounts ".date('l jS F Y \a\t g:i:a')); ?>">Export to CSV</button>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\spectrum\resources\views/licenses/accounting-module.blade.php ENDPATH**/ ?>