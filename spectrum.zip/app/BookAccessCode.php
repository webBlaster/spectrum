<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\Pivot;

class BookAccessCode extends model
{
    //

    protected $table = 'book_access_code';
}
