module.export = {
    devServer: {
        proxy: 'backend.test',
    }
}