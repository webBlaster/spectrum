@extends('layouts.layout')

@section('content')
<main class="content-wrapper">
  <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
    <div class="mdc-card p-0 ml-2">
      <load-keys></load-keys>
  </div>
</main>


@endsection

