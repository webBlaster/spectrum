@extends('layouts.layout')

@section('content')
  <used-licenses category="all"></used-licenses>
@endsection

