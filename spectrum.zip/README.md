## Spectrum Application API

Note I created factories for the database data, remember to seed when creating the migrations
 
The full documentation will be added soon